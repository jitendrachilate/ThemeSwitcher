﻿//Resolve conflicts calling global $ between Prototype and jQuery
jQuery.noConflict();// Cancels conflicts for jQuery defined in xaquery.js