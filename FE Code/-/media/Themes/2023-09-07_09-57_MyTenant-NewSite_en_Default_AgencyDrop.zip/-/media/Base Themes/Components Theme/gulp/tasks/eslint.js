import gulp from 'gulp';
import eslint from 'gulp-eslint';
//
import login from './login';
import config from '../config';
//

gulp.task('eslint', () => {
    var conf = config.js;
    // ESLint ignores files with "node_modules" paths.
    // Therefore, it's best to have gulp also ignore the directory.
    // Also, make sure to return the stream from the task.
    // Otherwise, the task may end before the stream has finished.
    return gulp.src([conf.path, '!node_modules/**'])
        // eslint() attaches the lint output to the "eslint" property
        // of the file object so it can be used by other modules.
        .pipe(eslint())
        // eslint.format() outputs the lint results to the console.
        // Alternatively use eslint.formatEach() (see Docs).
        .pipe(eslint.format())
        // To have the process exit with an error code (1) on
        // lint error, return the stream and pipe to failAfterError last.
        .pipe(eslint.failAfterError());
});